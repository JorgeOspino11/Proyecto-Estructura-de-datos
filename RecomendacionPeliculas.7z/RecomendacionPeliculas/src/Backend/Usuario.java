package Backend;

import java.util.*;

public class Usuario {
    private String nombre;
    private List<String> historial;
    private List<String> favoritos;
    private Map<String, Integer> calificaciones;

    public Usuario(String nombre) {
        this.nombre = nombre;
        this.historial = new ArrayList<>();
        this.favoritos = new ArrayList<>();
        this.calificaciones = new HashMap<>();
    }

    public String getNombre() {
        return nombre;
    }

    public List<String> getHistorial() {
        return historial;
    }

    public List<String> getFavoritos() {
        return favoritos;
    }

    public Map<String, Integer> getCalificaciones() {
        return calificaciones;
    }

    public void agregarAlHistorial(String pelicula) {
        historial.add(pelicula);
    }

    public void agregarAFavoritos(String pelicula) {
        if (!favoritos.contains(pelicula)) {
            favoritos.add(pelicula);
        }
    }

    public void agregarCalificacion(String pelicula, int calificacion) {
        calificaciones.put(pelicula, calificacion);
    }

    public Integer obtenerCalificacion(String pelicula) {
        return calificaciones.getOrDefault(pelicula, null);
    }
}
